# rules.md — Extended Reference

> **Note:** Core rules are in `/CLAUDE.md`. This file contains detailed reference and troubleshooting.

---

## Taxonomy Values Reference

### frameworks
`space-law`, `international-treaties`, `space-policy`, `standards`

### technologies
`transport-systems`, `spacecrafts`, `ground-systems`, `planetary-infrastructures`

### stakeholders
`governments`, `space-industry`, `agencies-institutions`, `international-entities`

### purposes
`knowledge-expansion`, `terrestrial-services`, `economic-development`, `space-exploration`

---

## i18n Keys Reference

See `i18n/en.toml` and `i18n/it.toml` for all available keys.

**Common keys:**
- `latest_articles`, `all_articles`
- `read_more`, `posted_on`
- `methodologies_link`
- Menu items, footer, pagination

---

## Module Mount Priority
1. `shared/` — Highest (common files)
2. `{site}/layouts/` — Site-specific overrides
3. `theme/` — Zen theme (lowest)

### When to use shared/
- Identical partials for both sites
- Common i18n translations
- Reusable UI components

### When to use site-specific layouts/
- Homepage (different per site)
- Site-specific branding
- Unique functionality

---

## Language Switcher Behavior
- If translation exists → Link to translated page
- If translation missing → Link to other language homepage
- Template: `layouts/_partials/menu.html`
- CSS class: `.sp-menu-lang`

---

## Menu Configuration (Italian)

In `hugo.yaml`:
```yaml
languages:
  it:
    menu:
      main:
        - name: "Articoli"
          url: "/article/"
        - name: "Tag"
          url: "/tags/"
        - name: "Chi Siamo"
          url: "/about/"
```

---

## Content File Structure
```
content/
├── about.md              # English
├── about.it.md           # Italian
├── article/
│   ├── _index.md         # Section index EN
│   ├── _index.it.md      # Section index IT
│   └── post-slug/
│       ├── index.md      # EN content
│       └── index.it.md   # IT content (optional)
```

---

## Troubleshooting

### Language switcher not appearing
- Check `hugo.IsMultilingual` in config
- Verify 2+ languages configured

### Translations not applied
- Check TOML syntax (no spaces before `=`)
- Rebuild: `hugo --gc && hugo server`

### Filters not working
- **Never translate taxonomy values**
- Verify kebab-case format
- Check `js/tagfilter.js` is unmodified

### Build errors
```bash
hugo --gc --cleanDestinationDir
hugo server --disableFastRender
```

---

## Implementation History

**2025-01-12:** Initial multilingual implementation
- EN + IT configuration
- Terminal-style language switcher
- Complete i18n system
- Taxonomy system with English-only values

---

## aa-kb/ Directory

Personal knowledge base. **Read only if user explicitly requests.**

Contents: personal notes, prompts, other project docs.
